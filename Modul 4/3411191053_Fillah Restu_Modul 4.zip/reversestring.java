// Fillah Restu Kurnia - 3411191053 - DSE B
// 4.1.4 Reverse String
import java.util.*;

public class reversestring {
  	public static void main(String args[]) {
    	String huruf, hasil = "";
    	Scanner scanner = new Scanner(System.in);

    	System.out.print("Masukkan string: ");
    	huruf = scanner.nextLine();

    	int jumlah = huruf.length();
    	int jumlahHuruf = jumlah - 1;
    	for (int i = 0; i < jumlah; i++) {
      		hasil = hasil + huruf.charAt(jumlahHuruf);
      		jumlahHuruf--;
    	}
    	System.out.println("Hasil reverse string: " + hasil);
  	}
}
