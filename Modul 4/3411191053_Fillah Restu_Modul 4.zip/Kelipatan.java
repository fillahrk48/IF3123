// Fillah Restu Kurnia - 3411191053 - DSE B
// 4.1.1 Jumlah Kelipatan 
import java.io.*;
class Kelipatan{	
static int findSum(int n, int a, int b){
 	int sum = 0;
 	for (int i = 0; i < n; i++)
 		
		if (i % a == 0 || i % b == 0)
			sum += i;		
 	return sum;
}
public static void main(String[] args){
 	int n = 1000, a = 3, b = 5;
 	System.out.println(findSum(n, a, b));
 	}
}
